"""Timer module for candle animations"""

from .CandleTimer import CandleTimer

__all__ = ['CandleTimer']
